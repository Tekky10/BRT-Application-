<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BrtRoutesController extends Controller
{
    //
}
