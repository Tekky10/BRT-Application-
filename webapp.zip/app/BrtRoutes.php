<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BrtRoutes extends Model
{
    //
}
